#import <Foundation/Foundation.h>
#import "NGLFoundation.h"

NGL_EXPORT

extern NSString *const baseUrl;

extern NSString *const directions;

extern NSString *const matrix;

extern NSString *const matching;

@interface APIConstants : NSObject


@end
